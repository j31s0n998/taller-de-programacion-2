/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tomarmatusculas;

/**
 *
 * @author Pc
 */
public class TomarMatusculas {

    public static void main(String[] args) {
String palabra= "QUesItoxDlOLDiAmantE";
        int contador = 0;
        for (int i = 0; i < palabra.length(); i++) {
            if (Character.isUpperCase(palabra.charAt(i))) {
                contador++;
            }
        }
        
        System.out.println("La palabra tiene " + contador + " mayúsculas.");    }
}
