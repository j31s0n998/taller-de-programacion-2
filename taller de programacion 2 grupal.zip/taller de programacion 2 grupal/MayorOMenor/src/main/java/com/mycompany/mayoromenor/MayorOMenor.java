/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mayoromenor;

/**
 *
 * @author Pc
 */
public class MayorOMenor {

    public static void main(String[] args) {
        int num1=2;
        int num2=5;
        if(num1<num2){
        
            System.out.println("el "+ num1 +" es menor que el "+ num2);
        }
        else{
        if(num1>num2){
            System.out.println("el "+ num1 +" es mayor que el "+ num2);
        
        
        }
        else{
            System.out.println("son iguales wey");
        }
        }    }
}
