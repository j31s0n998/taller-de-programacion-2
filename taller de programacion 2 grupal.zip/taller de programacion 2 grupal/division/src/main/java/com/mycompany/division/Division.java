/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.division;

/**
 *
 * @author Pc
 */
public class Division {

    public static void main(String[] args) {
        int num2=7;
        int num1=0;
      if(num2!=0){
         double resultado= (double)num1/num2;
            System.out.println("el resultado es "+ resultado );
        }    
        else{
        
            System.out.println("como se le ocurre dividir por 0 wey xd");
        }    }
}
