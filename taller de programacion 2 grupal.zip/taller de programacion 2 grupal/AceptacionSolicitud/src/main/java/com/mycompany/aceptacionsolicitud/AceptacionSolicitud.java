/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aceptacionsolicitud;

/**
 *
 * @author Pc
 */
public class AceptacionSolicitud {

    public static void main(String[] args) {
        int edad = 0;
        int nota = 0;
        char sexo = 0;
     if(nota>=5&& edad>=18){
           if(sexo=='M'){
               System.out.println("posible");
            }
           else if(sexo=='F'){
               System.out.println("aceptable");
            }
        }
               System.out.println("acceso denegado xd");
    }   

}

