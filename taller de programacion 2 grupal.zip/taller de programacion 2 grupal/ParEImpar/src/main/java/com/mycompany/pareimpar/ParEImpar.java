/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pareimpar;

/**
 *
 * @author Pc
 */
public class ParEImpar {

    public static void main(String[] args) {
        int num1 = 0;
        if(num1%2==0){
        System.out.println("es par");
       }
       else{
        System.out.println("es impar");
       }    }
}
